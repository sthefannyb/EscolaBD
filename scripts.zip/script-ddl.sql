-- =============================================
-- BANCO DE DADOS: EscolaBD
-- Sistema de Gestão Escolar
-- =============================================

DROP DATABASE IF EXISTS EscolaBD;

CREATE DATABASE EscolaBD;

USE EscolaBD;

-- =============================================
-- 1. RESPONSAVEL
-- Responsável financeiro/legal do aluno
-- =============================================

CREATE TABLE Responsavel (
idResponsavel INT UNSIGNED NOT NULL AUTO_INCREMENT,
nome VARCHAR(100) NOT NULL,
CPF CHAR(11) NOT NULL UNIQUE,
telefone VARCHAR(15) NOT NULL,
email VARCHAR(100) NOT NULL UNIQUE,

PRIMARY KEY (idResponsavel)
);

-- =============================================
-- 2. ALUNO
-- Aluno vinculado a um responsável
-- =============================================

CREATE TABLE Aluno (
idAluno INT UNSIGNED NOT NULL AUTO_INCREMENT,
nome VARCHAR(100) NOT NULL,
CPF CHAR(11) NOT NULL UNIQUE,
data_nascimento DATE NOT NULL,
logradouro VARCHAR(150) NOT NULL,
numero VARCHAR(10) NOT NULL,
bairro VARCHAR(60) NOT NULL,
cidade VARCHAR(60) NOT NULL,
uf CHAR(2) NOT NULL,
cep CHAR(8) NOT NULL,
idResponsavel INT UNSIGNED NOT NULL,

PRIMARY KEY (idAluno),

CONSTRAINT fk_aluno_responsavel
FOREIGN KEY (idResponsavel)
REFERENCES Responsavel(idResponsavel)
ON UPDATE CASCADE
);

-- =============================================
-- 3. ANO ESCOLAR
-- Séries e turmas ofertadas pela escola
-- =============================================

CREATE TABLE AnoEscolar (
idAnoEscolar INT UNSIGNED NOT NULL AUTO_INCREMENT,
serie VARCHAR(50) NOT NULL,
turma CHAR(1) NOT NULL,
turno VARCHAR(15) NOT NULL,
ano_letivo INT UNSIGNED NOT NULL,

PRIMARY KEY (idAnoEscolar),

UNIQUE (serie, turma, turno, ano_letivo)
);

-- =============================================
-- 4. MATRICULA
-- Relaciona aluno e ano escolar
-- =============================================

CREATE TABLE Matricula (
idMatricula INT UNSIGNED NOT NULL AUTO_INCREMENT,
data_matricula DATE NOT NULL,
status VARCHAR(45) NOT NULL DEFAULT 'Ativa',
valor_anuidade DECIMAL(10,2) NOT NULL,
idAluno INT UNSIGNED NOT NULL,
idAnoEscolar INT UNSIGNED NOT NULL,

PRIMARY KEY (idMatricula),

UNIQUE KEY uk_aluno_turma (idAluno, idAnoEscolar),

CONSTRAINT chk_anuidade
CHECK (valor_anuidade > 0),

CONSTRAINT chk_status_matricula
CHECK (status IN ('Ativa', 'Concluída', 'Cancelada')),

CONSTRAINT fk_matricula_aluno
FOREIGN KEY (idAluno)
REFERENCES Aluno(idAluno)
ON DELETE CASCADE ON UPDATE CASCADE,

CONSTRAINT fk_matricula_ano
FOREIGN KEY (idAnoEscolar)
REFERENCES AnoEscolar(idAnoEscolar)
ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 5. MENSALIDADE
-- Controle financeiro das matrículas
-- =============================================

CREATE TABLE Mensalidade (
idMensalidade INT UNSIGNED NOT NULL AUTO_INCREMENT,
numero_parcela TINYINT UNSIGNED NOT NULL,
valor DECIMAL(10,2) NOT NULL,
data_vencimento DATE NOT NULL,
status_pagamento VARCHAR(20) NOT NULL DEFAULT 'Pendente',
idMatricula INT UNSIGNED NOT NULL,

PRIMARY KEY (idMensalidade),

CONSTRAINT chk_numero_parcela
CHECK (numero_parcela BETWEEN 1 AND 12),

CONSTRAINT chk_valor_mensalidade
CHECK (valor > 0),

CONSTRAINT chk_status_pagamento
CHECK (status_pagamento IN ('Pendente', 'Pago', 'Atrasado')),

CONSTRAINT fk_mensalidade_matricula
FOREIGN KEY (idMatricula)
REFERENCES Matricula(idMatricula)
ON DELETE CASCADE ON UPDATE CASCADE
);

-- =============================================
-- 6. PROFESSOR
-- Corpo docente da escola
-- =============================================

CREATE TABLE Professor (
idProfessor INT UNSIGNED NOT NULL AUTO_INCREMENT,
nome VARCHAR(100) NOT NULL,
CPF CHAR(11) NOT NULL UNIQUE,
formacao VARCHAR(100) NOT NULL,
email VARCHAR(100) NOT NULL UNIQUE,

PRIMARY KEY (idProfessor)
);

-- =============================================
-- 7. DISCIPLINA
-- Matérias da grade curricular
-- =============================================

CREATE TABLE Disciplina (
idDisciplina INT UNSIGNED NOT NULL AUTO_INCREMENT,
nome_disciplina VARCHAR(80) NOT NULL UNIQUE,
carga_horaria_anual INT UNSIGNED NOT NULL,
descricao VARCHAR(200) NOT NULL,

PRIMARY KEY (idDisciplina),

CONSTRAINT chk_carga_horaria
CHECK (carga_horaria_anual > 0)
);

-- =============================================
-- 8. GRADE TURMA
-- Relaciona ano escolar, disciplina e professor
-- =============================================

CREATE TABLE GradeTurma (
idAnoEscolar INT UNSIGNED NOT NULL,
idDisciplina INT UNSIGNED NOT NULL,
idProfessor INT UNSIGNED NOT NULL,
carga_horaria_semanal INT UNSIGNED NOT NULL,

PRIMARY KEY (idAnoEscolar, idDisciplina),

CONSTRAINT chk_carga_semanal
CHECK (carga_horaria_semanal > 0),

CONSTRAINT fk_gt_ano
FOREIGN KEY (idAnoEscolar)
REFERENCES AnoEscolar(idAnoEscolar)
ON DELETE CASCADE ON UPDATE CASCADE,

CONSTRAINT fk_gt_disciplina
FOREIGN KEY (idDisciplina)
REFERENCES Disciplina(idDisciplina)
ON DELETE CASCADE ON UPDATE CASCADE,

CONSTRAINT fk_gt_professor
FOREIGN KEY (idProfessor)
REFERENCES Professor(idProfessor)
ON UPDATE CASCADE
);

-- =============================================
-- FIM DO SCRIPT DDL
-- =============================================
