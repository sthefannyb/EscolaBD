-- ============================================================================
-- PROJETO: Sistema de Gestão Escolar (Escola Privada - Ensino Regular)
-- ARQUIVO: script-dml.sql
-- DESCRIÇÃO: Povoamento de dados orientado a cenários cronológicos reais.
-- ============================================================================

USE EscolaBD;

-- ============================================================================
-- Cenário 1 — Estruturação Pedagógica, Corpo Docente e Turmas (Dados Base):
--
-- Antes de iniciar o período de matrículas de 2026, a direção pedagógica
-- cadastrou as 5 disciplinas fundamentais do currículo, registrou os 5
-- professores titulares e abriu 5 turmas contemplando o histórico de 2025
-- e as vagas disponíveis para o ano letivo de 2026.
-- ============================================================================

INSERT INTO Disciplina (nome_disciplina, carga_horaria_anual, descricao) VALUES
    ('Matemática', 160, 'Álgebra, geometria plana e espacial, trigonometria e funções.'),
    ('Língua Portuguesa', 160, 'Gramática normativa, interpretação textual, literatura e redação.'),
    ('História', 80, 'História Geral e do Brasil, análise crítica e formação cidadã.'),
    ('Biologia', 120, 'Citologia, genética, ecologia e fisiologia humana.'),
    ('Física', 120, 'Mecânica clássica, termodinâmica, óptica e eletromagnetismo.');

INSERT INTO Professor (nome, CPF, formacao, email) VALUES
    ('Marcos Vinícius Almeida', '11122233344', 'Licenciatura em Matemática', 'marcos.almeida@escola.com.br'),
    ('Juliana Costa Mendes', '22233344455', 'Licenciatura em Letras - Português', 'juliana.mendes@escola.com.br'),
    ('Ricardo Oliveira Santos', '33344455566', 'Mestrado em História Social', 'ricardo.santos@escola.com.br'),
    ('Fernanda Lima Duarte', '44455566677', 'Licenciatura em Ciências Biológicas', 'fernanda.duarte@escola.com.br'),
    ('Thiago Henrique Nogueira', '55566677788', 'Licenciatura em Física', 'thiago.nogueira@escola.com.br');

INSERT INTO AnoEscolar (serie, turma, turno, ano_letivo) VALUES
    ('1º Ano Ensino Médio', 'A', 'Matutino', 2025),
    ('1º Ano Ensino Médio', 'A', 'Matutino', 2026),
    ('2º Ano Ensino Médio', 'A', 'Matutino', 2026),
    ('3º Ano Ensino Médio', 'A', 'Matutino', 2026),
    ('9º Ano Ensino Fundamental', 'B', 'Vespertino', 2026);

-- ============================================================================
-- Cenário 2 — Montagem da Grade Curricular das Turmas (Relacionamento N:M):
--
-- Com os professores e as turmas de 2026 definidos, a coordenação montou
-- a grade de aulas vinculando as disciplinas aos respectivos anos escolares
-- e definindo a carga horária semanal de cada docente.
-- ============================================================================

INSERT INTO GradeTurma (idAnoEscolar, idDisciplina, idProfessor, carga_horaria_semanal) VALUES
    (2, 1, 1, 4), -- 1º Ano A (2026) -> Matemática (Prof. Marcos)
    (2, 2, 2, 4), -- 1º Ano A (2026) -> Português (Profa. Juliana)
    (3, 1, 1, 4), -- 2º Ano A (2026) -> Matemática (Prof. Marcos)
    (3, 4, 4, 3), -- 2º Ano A (2026) -> Biologia (Profa. Fernanda)
    (4, 5, 5, 3), -- 3º Ano A (2026) -> Física (Prof. Thiago)
    (5, 3, 3, 2); -- 9º Ano B (2026) -> História (Prof. Ricardo)

-- ============================================================================
-- Cenário 3 — Cadastro das Famílias (Responsáveis Financeiros e Alunos):
--
-- Durante a campanha de matrículas de janeiro de 2026, cinco famílias
-- compareceram à secretaria da escola para cadastrar os responsáveis
-- financeiros e os dados residenciais e pessoais dos estudantes.
-- ============================================================================

INSERT INTO Responsavel (nome, CPF, telefone, email) VALUES
    ('Roberto Carlos Silva', '90190290311', '84999112233', 'roberto.silva@email.com'),
    ('Ana Paula Oliveira', '90290390422', '84988223344', 'anapaula.oliveira@email.com'),
    ('Cláudio Ferreira Gomes', '90390490533', '84991334455', 'claudio.gomes@email.com'),
    ('Patrícia Souza Dantas', '90490590644', '84994445566', 'patricia.dantas@email.com'),
    ('Sérgio Augusto Bezerra', '90590690755', '84987556677', 'sergio.bezerra@email.com');

INSERT INTO Aluno (nome, CPF, data_nascimento, logradouro, numero, bairro, cidade, uf, cep, idResponsavel) VALUES
    ('Carlos Eduardo Silva', '60160260311', '2010-04-12', 'Rua das Flores', '100', 'Centro', 'Natal', 'RN', '59000100', 1),
    ('Maria Fernanda Oliveira', '60260360422', '2010-09-25', 'Avenida Hermes da Fonseca', '840', 'Tirol', 'Natal', 'RN', '59020000', 2),
    ('Lucas Gabriel Gomes', '60360460533', '2011-02-18', 'Rua São José', '45', 'Lagoa Nova', 'Natal', 'RN', '59050200', 3),
    ('Beatriz Dantas Medeiros', '60460560644', '2009-11-30', 'Avenida Roberto Freire', '1200', 'Ponta Negra', 'Natal', 'RN', '59090000', 4),
    ('Rafael Henrique Bezerra', '60560660755', '2012-06-07', 'Rua Jaguarari', '310', 'Barro Vermelho', 'Natal', 'RN', '59030500', 5);

-- ============================================================================
-- Cenário 4 — Efetivação das Matrículas (Histórico 2025 e Renovação/Novos 2026):
--
-- O aluno Carlos Eduardo já estudava na escola em 2025 (1º Ano A - Concluída)
-- e renovou sua matrícula para o 2º Ano A em 2026. Os demais estudantes
-- ocuparam vagas nas turmas de 1º Ano, 2º Ano, 3º Ano e 9º Ano em 2026.
-- ============================================================================

INSERT INTO Matricula (data_matricula, status, valor_anuidade, idAluno, idAnoEscolar) VALUES
    ('2025-01-10', 'Concluída', 12000.00, 1, 1),
    ('2026-01-12', 'Ativa', 13200.00, 1, 3),
    ('2026-01-14', 'Ativa', 13200.00, 2, 3),
    ('2026-01-15', 'Ativa', 12600.00, 3, 2),
    ('2026-01-18', 'Ativa', 14400.00, 4, 4),
    ('2026-01-20', 'Ativa', 11400.00, 5, 5);

-- ============================================================================
-- Cenário 5 — Faturamento e Baixa das Primeiras Mensalidades de 2026:
--
-- Após a assinatura dos contratos de matrícula de 2026, o setor financeiro
-- gerou as parcelas mensais e registrou as quitações de fevereiro ('Pago')
-- e as parcelas ainda em aberto ('Pendente' ou 'Atrasado').
-- ============================================================================

INSERT INTO Mensalidade (numero_parcela, valor, data_vencimento, status_pagamento, idMatricula) VALUES
    (1, 1100.00, '2026-02-10', 'Pago', 2),
    (2, 1100.00, '2026-03-10', 'Pendente', 2),
    (1, 1100.00, '2026-02-10', 'Pago', 3),
    (1, 1050.00, '2026-02-10', 'Atrasado', 4),
    (1, 1200.00, '2026-02-10', 'Pago', 5),
    (1, 950.00,  '2026-02-10', 'Pago', 6);